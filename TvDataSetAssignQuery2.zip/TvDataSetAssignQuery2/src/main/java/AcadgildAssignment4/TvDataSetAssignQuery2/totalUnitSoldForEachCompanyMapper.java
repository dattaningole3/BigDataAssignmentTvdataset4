package AcadgildAssignment4.TvDataSetAssignQuery2;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;


public class totalUnitSoldForEachCompanyMapper extends Mapper<LongWritable, Text, Text, IntWritable> {

	
	@Override
	protected void map(LongWritable key, Text value, Context context)
			throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		if(recordIsInvalid(value)==false) {
			Text company=new Text();
			IntWritable unit=new IntWritable(1);
			String[] companystring=value.toString().split("\\|");
			company=new Text(companystring[0]);
			context.write(company, unit);
		}
	 
	}
	
	private boolean recordIsInvalid(Text record) {
		boolean recordvalue=false;
		String[] linearray=record.toString().split("\\|");
		
		for(int i=0;i<linearray.length;i++) {
			if(linearray[i]=="NA") {
				recordvalue=true;
			}
		}
		return recordvalue;
		
	}
	

}
