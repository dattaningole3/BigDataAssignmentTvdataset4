package AcadgildAssignment4.TvDataSetAssignQuery3;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class TvDataSetQuery3 {

public static class TvSalesMapper extends Mapper<LongWritable, Text, Text, IntWritable>{
		
		public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException{
	
		    if(recordIsInvalid(value)==false & value.toString().split("\\|")[0].equals("Onida")){
		        Text state = new Text();
			IntWritable unit = new IntWritable();				
			state = new Text(value.toString().split("\\|")[3]);
			unit = new IntWritable(1);
			context.write(state, unit );
		    }

		}
		
		private boolean recordIsInvalid(Text record){
			
			String[] lineArray = record.toString().split("\\|");
			boolean isInvalid = false;
	        for(int i=0;i<lineArray.length;i++){
	        	if(lineArray[i].equals("NA")){
	        		isInvalid = true;
	        	}
	        }
	        return isInvalid;
		}
	}
	public static class TvSalesReducer extends Reducer<Text, IntWritable, Text, IntWritable>{
		
		private IntWritable result = new IntWritable();
		
		public void reduce (Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException{			
			int sum = 0;
			for(IntWritable val: values){
				sum += val.get();		
			}
			result.set(sum);
			context.write(key, result);
		}
	}

	public static void main(String[] args) throws Exception{

	    Configuration conf = new Configuration();	
		
	    Job job = Job.getInstance(conf, "Tv Sales in each state for Onida Company ");
	    job.setJarByClass(TvDataSetQuery3.class);
	    
	    job.setMapOutputKeyClass(Text.class);
	    job.setMapOutputValueClass(IntWritable.class);
	    
	    job.setOutputKeyClass(Text.class);
	    job.setOutputValueClass(IntWritable.class);
	    
	    job.setMapperClass(TvSalesMapper.class);
	    job.setCombinerClass(TvSalesReducer.class);
	    job.setReducerClass(TvSalesReducer.class);  
	    
	    FileInputFormat.addInputPath(job, new Path(args[0]));
	    FileOutputFormat.setOutputPath(job, new Path(args[1]));
	    
	    System.exit(job.waitForCompletion(true) ? 0 : 1);  	    	    	    
	}

}
